# multiAgents.py
# --------------


from audioop import reverse
from multiprocessing.dummy import current_process
from xmlrpc.client import MAXINT, MININT
from pacman import SCARED_TIME
from util import manhattanDistance
from game import Directions
import random, util

from game import Agent

class ReflexAgent(Agent):
    """
    A reflex agent chooses an action at each choice point by examining
    its alternatives via a state evaluation function.

    The code below is provided as a guide.  You are welcome to change
    it in any way you see fit, so long as you don't touch our method
    headers.
    """


    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {NORTH, SOUTH, WEST, EAST, STOP}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action) #grafico de laberinto
        newPos = successorGameState.getPacmanPosition() # coordenada (de a donde se puede mover?) pacman
        newFood = successorGameState.getFood() # matriz true false
        newGhostStates = successorGameState.getGhostStates() # [action ......]
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates] #[0, array]

        "*** YOUR CODE HERE ***"
        cost =0


        if len(newFood.asList())!=0:
            
            ###### MIRANDO LA COMIDA #####
            foodDist = []
            # Rellenar el vector de distancia a la a comida en orden
            for food in newFood.asList():
                manhattanDist = util.manhattanDistance(newPos, food)
                foodDist.append(manhattanDist)

            # Tener en cuenta cuanto de cerca está la comida (distancia maxima de manhattan segun este tablero >>>>> 18x9=27)
            for dist in foodDist:
                if dist <= 4:
                    cost += 10
                elif dist > 4 and dist <= 10:
                    cost += 8
                elif dist > 10 and dist <= 18:
                    cost += 1
                else:
                    cost += 0.5
            
        
        ###### MIRANDO Los ghosts #####
        ghostDist = []
        i = 0

        for ghost in successorGameState.getGhostPositions():
            if (newScaredTimes[i])==0: # ghost no asustado (tiempo=0)
                ghostManhattanDist = util.manhattanDistance(newPos, ghost)
                # miramos a ver si un fantasma le ha comido
                if(ghostManhattanDist)==0:
                    return MININT
                # Rellenar el vector de distancia al ghost en orden
                ghostDist.append(ghostManhattanDist)    
            i+=1

        # Tener en cuenta cuanto de cerca está el ghost (distancia maxima de manhattan segun este tablero >>>>> 18x9=27)
        for dist in ghostDist:
            if dist <= 3.5:
                cost = 1 - cost
            else:
                cost = dist*4 + cost
                
        
        
        return cost



def scoreEvaluationFunction(currentGameState):
    """
    This default evaluation function just returns the score of the state.
    The score is the same one displayed in the Pacman GUI.

    This evaluation function is meant for use with adversarial search agents
    (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
    This class provides some common elements to all of your
    multi-agent searchers.  Any methods defined here will be available
    to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

    You *do not* need to make any changes here, but you can if you want to
    add functionality to all your adversarial search agents.  Please do not
    remove anything, however.

    Note: this is an abstract class: one that should not be instantiated.  It's
    only partially specified, and designed to be extended.  Agent (game.py)
    is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
    Your minimax agent (question 2)
    """

    def getAction(self, gameState):
        """
        Returns the minimax action from the current gameState using self.depth
        and self.evaluationFunction.

        Here are some method calls that might be useful when implementing minimax.

        gameState.getLegalActions(agentIndex):
        Returns a list of legal actions for an agent
        agentIndex=0 means Pacman, ghosts are >= 1

        gameState.generateSuccessor(agentIndex, action):
        Returns the successor game state after an agent takes an action

        gameState.getNumAgents():
        Returns the total number of agents in the game

        gameState.isWin():
        Returns whether or not the game state is a winning state

        gameState.isLose():
        Returns whether or not the game state is a losing state
        """
        "*** YOUR CODE HERE ***"
        bestScore,bestMove=self.maxFunction(gameState,self.depth) # Empleando recursividad con min y max

        return bestMove


    def maxFunction(self,gameState,depth):
        if depth==0 or gameState.isWin() or gameState.isLose():
          return self.evaluationFunction(gameState), None  # do not move!!!!

        else:
            movements = gameState.getLegalActions() # Returns a list of legal actions for an agent
            maxScore = MININT
            maxScoreIndex = 0
            i=0
            for move in movements:
                score = self.minFunction(gameState.generateSuccessor(self.index,move),1, depth)[0]  # FIRST ITERATION >> Agent 1 is ghost number 1 (pacman is 0)
                if maxScore < score:
                    maxScore = score
                    maxScoreIndex = i
                i+=1
            return maxScore,movements[maxScoreIndex]

        
    def minFunction(self,gameState,agent, depth):  # agent = 1, 2, 3.... (para todos los ghosts)
        if depth==0 or gameState.isWin() or gameState.isLose():
          return self.evaluationFunction(gameState), "noMove"
      
        else:
            movements = gameState.getLegalActions(agent) # Returns a list of legal actions for an agent
            minScore = MAXINT
            minScoreIndex = 0
            i=0
            if(agent!=gameState.getNumAgents()-1): # 1=1???
                for move in movements:
                    score = self.minFunction(gameState.generateSuccessor(agent,move),agent+1,depth)[0] # Next ghost= agent+1
                    if minScore > score:
                        minScore = score
                        minScoreIndex = i
                    i+=1
            else:
                for move in movements:
                    minScore = self.maxFunction(gameState.generateSuccessor(agent,move),(depth-1))[0] # Max score of pacman that is in (depth-1)
                    minScoreIndex = 0
            
            
            return minScore, movements[minScoreIndex]
        
class AlphaBetaAgent(MultiAgentSearchAgent):
    """
    Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState):
        """
        Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"
        util.raiseNotDefined()

class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState):
        """
        Returns the expectimax action using self.depth and self.evaluationFunction

        All ghosts should be modeled as choosing uniformly at random from their
        legal moves.
        """
        "*** YOUR CODE HERE ***"
        util.raiseNotDefined()

def betterEvaluationFunction(currentGameState):
    """
    Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
    evaluation function (question 5).

    DESCRIPTION: <write something here so we know what you did>
    """
    "*** YOUR CODE HERE ***"
    util.raiseNotDefined()

# Abbreviation
better = betterEvaluationFunction
